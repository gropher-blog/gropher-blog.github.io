<?php get_header(); ?>

				<div id="leftcontent">

		<h2 class="pagetitle">Error 404 - Not Found</h2>

	</div><!--leftcontent-->

<?php get_sidebar(); ?>

<?php get_footer(); ?>