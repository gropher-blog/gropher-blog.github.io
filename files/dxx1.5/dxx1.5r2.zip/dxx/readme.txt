Theme Name: DXX
Theme URI: http://blog.gropher.net/?p=11
Description: DXX, based on the famous <a href="http://binarybonsai.com/kubrick/">Kubrick</a>, is a simple and clean theme for <a href="http://wordpress.org/">WordPress 1.5</a>.
Version: 1.5, Release 2
Release Date: 19 April 2006
Author: gropher
Author E-mail: gropher at gmail dot com
Author URI: http://blog.gropher.net/

	This theme was designed by gropher,whose blog you will find at:
   http://blog.gropher.net/
  
  and you will find the latest news and  announcements of DXX in category named "wordpress":
  http://blog.gropher.net/?cat=6
  
	The CSS, XHTML and design is released under CC/GNU GPL:
	http://creativecommons.org/licenses/GPL/2.0/
	
	Release notes:
	
	- 19 April 2006
		2nd release.
		Their is no change for the code.
		The reason for update is the transfer of the blog server, and I just modified some contact info.
		The theme is still for wordpress 1.5, I did not tested for wordpress 2.0 or above.
		For those who are interested, please keep eyes on my blog post. I'd like to make a new version for wordpress, but the release date is not fixed.
	
	- 14 March 2005
		1st release, under the name SupremeColor.